#include<stdio.h>
int main(){
  int i,j;
  for(i=1;i<=50;i++){
    j=i*7;
    printf("%d fois 7 est %d\n",i,j);
  }
  return 0;
}
    
