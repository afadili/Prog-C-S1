#include<stdio.h>
int main(){
  int a=1,b;
  while(a<=50){
    b=a*7;
    printf("%d fois 7 est %d\n",a,b);
    a=a+1;
  }
}
