#include<stdio.h>
int main(){
  int a=0;
  while(a<50){
    a=a+1;
    printf("%d\n",a);
  }
}
