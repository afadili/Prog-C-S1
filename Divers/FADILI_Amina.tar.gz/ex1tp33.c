#include<stdio.h>
int main(){
  int a;
  for (a=1; a<=50; a++){
    printf("%d\n",a);
  }
  return 0;
}
